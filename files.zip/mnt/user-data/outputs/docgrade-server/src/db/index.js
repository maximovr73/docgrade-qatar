import pg from "pg";
import { config } from "../config.js";

const { Pool } = pg;

// ─── Postgres connection pool ───────────────────────────────────────────────
// Replaces the earlier node:sqlite implementation. Two real problems drove
// this switch, both confirmed in testing during development:
//   1. Cloud platforms like Railway/Render don't guarantee a persistent local
//      disk across deploys unless you explicitly attach a volume — a file-based
//      SQLite db would silently reset on every redeploy otherwise.
//   2. On FUSE-mounted storage (encountered during earlier testing on a
//      different host), spawning a child process (pdftotext) was found to
//      reliably invalidate the SQLite file handle, causing "disk I/O error".
//      A real network database connection doesn't have this failure mode —
//      the connection is independent of the local filesystem entirely.
//
// Set DATABASE_URL (Railway/Render inject this automatically when you attach
// a Postgres addon) to a standard postgres:// connection string.

export const pool = new Pool({
  connectionString: config.databaseUrl,
  // Most managed Postgres providers (Railway, Render, Supabase) require SSL
  // but use certificates not in Node's default trust store — this is the
  // standard, documented way to connect to them.
  ssl: config.databaseUrl?.includes("localhost") ? false : { rejectUnauthorized: false },
  max: 10,
});

pool.on("error", (err) => {
  // Fired on idle client errors (e.g. connection dropped by the server).
  // Logged, not thrown — individual queries handle their own errors via
  // their own try/catch at the call site.
  console.error("[db] Unexpected error on idle Postgres client:", err.message);
});

const SCHEMA_SQL = `
  CREATE TABLE IF NOT EXISTS moph_documents (
    id            SERIAL PRIMARY KEY,
    source_url    TEXT NOT NULL UNIQUE,
    title         TEXT NOT NULL,
    icd10_hint    TEXT,
    fetched_at    TIMESTAMPTZ NOT NULL,
    content_hash  TEXT NOT NULL,
    raw_text_len  INTEGER NOT NULL DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS moph_chunks (
    id           SERIAL PRIMARY KEY,
    document_id  INTEGER NOT NULL REFERENCES moph_documents(id) ON DELETE CASCADE,
    chunk_index  INTEGER NOT NULL,
    text         TEXT NOT NULL,
    token_count  INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS sync_runs (
    id            SERIAL PRIMARY KEY,
    started_at    TIMESTAMPTZ NOT NULL,
    finished_at   TIMESTAMPTZ,
    status        TEXT NOT NULL DEFAULT 'running',
    docs_found    INTEGER DEFAULT 0,
    docs_updated  INTEGER DEFAULT 0,
    docs_failed   INTEGER DEFAULT 0,
    error_message TEXT
  );

  CREATE INDEX IF NOT EXISTS idx_chunks_document ON moph_chunks(document_id);
  CREATE INDEX IF NOT EXISTS idx_documents_hash ON moph_documents(content_hash);
`;

let schemaReady = null;

/**
 * Ensures the schema exists. Called lazily on first query rather than at
 * import time, since import-time side effects make testing harder and can
 * fire before DATABASE_URL is even validated.
 */
async function ensureSchema() {
  if (!schemaReady) {
    schemaReady = pool.query(SCHEMA_SQL).catch((err) => {
      schemaReady = null; // allow retry on next call if this attempt failed
      throw err;
    });
  }
  return schemaReady;
}

async function withSchema(fn) {
  await ensureSchema();
  return fn();
}

export async function getLastSyncRun() {
  return withSchema(async () => {
    const { rows } = await pool.query(`SELECT * FROM sync_runs ORDER BY id DESC LIMIT 1`);
    return rows[0] || null;
  });
}

export async function getDocCount() {
  return withSchema(async () => {
    const { rows } = await pool.query(`SELECT COUNT(*)::int AS n FROM moph_documents`);
    return rows[0]?.n ?? 0;
  });
}

export async function getChunkCount() {
  return withSchema(async () => {
    const { rows } = await pool.query(`SELECT COUNT(*)::int AS n FROM moph_chunks`);
    return rows[0]?.n ?? 0;
  });
}

export async function startSyncRun() {
  return withSchema(async () => {
    const startedAt = new Date().toISOString();
    const { rows } = await pool.query(
      `INSERT INTO sync_runs (started_at, status) VALUES ($1, 'running') RETURNING id`,
      [startedAt]
    );
    return rows[0].id;
  });
}

export async function finishSyncRun(id, { status, docsFound, docsUpdated, docsFailed, errorMessage }) {
  return withSchema(async () => {
    await pool.query(
      `UPDATE sync_runs
       SET finished_at = $1, status = $2, docs_found = $3, docs_updated = $4, docs_failed = $5, error_message = $6
       WHERE id = $7`,
      [new Date().toISOString(), status, docsFound, docsUpdated, docsFailed, errorMessage ?? null, id]
    );
  });
}

export async function upsertDocument({ sourceUrl, title, icd10Hint, contentHash, rawTextLen }) {
  return withSchema(async () => {
    const existingRes = await pool.query(
      `SELECT id, content_hash FROM moph_documents WHERE source_url = $1`,
      [sourceUrl]
    );
    const existing = existingRes.rows[0];

    if (existing && existing.content_hash === contentHash) {
      return { id: existing.id, changed: false };
    }

    if (existing) {
      await pool.query(
        `UPDATE moph_documents
         SET title = $1, icd10_hint = $2, fetched_at = $3, content_hash = $4, raw_text_len = $5
         WHERE id = $6`,
        [title, icd10Hint ?? null, new Date().toISOString(), contentHash, rawTextLen, existing.id]
      );
      await pool.query(`DELETE FROM moph_chunks WHERE document_id = $1`, [existing.id]);
      return { id: existing.id, changed: true };
    }

    const insertRes = await pool.query(
      `INSERT INTO moph_documents (source_url, title, icd10_hint, fetched_at, content_hash, raw_text_len)
       VALUES ($1, $2, $3, $4, $5, $6) RETURNING id`,
      [sourceUrl, title, icd10Hint ?? null, new Date().toISOString(), contentHash, rawTextLen]
    );
    return { id: insertRes.rows[0].id, changed: true };
  });
}

export async function insertChunks(documentId, chunks) {
  return withSchema(async () => {
    const client = await pool.connect();
    try {
      await client.query("BEGIN");
      for (let i = 0; i < chunks.length; i++) {
        const tokenCount = Math.ceil(chunks[i].length / 4);
        await client.query(
          `INSERT INTO moph_chunks (document_id, chunk_index, text, token_count) VALUES ($1, $2, $3, $4)`,
          [documentId, i, chunks[i], tokenCount]
        );
      }
      await client.query("COMMIT");
    } catch (err) {
      await client.query("ROLLBACK");
      throw err;
    } finally {
      client.release();
    }
  });
}

export async function getAllChunksWithDoc() {
  return withSchema(async () => {
    const { rows } = await pool.query(
      `SELECT c.id, c.text, c.chunk_index, d.title, d.source_url, d.icd10_hint
       FROM moph_chunks c
       JOIN moph_documents d ON d.id = c.document_id`
    );
    return rows;
  });
}

/**
 * Closes the pool cleanly. Used on SIGTERM in index.js and in tests.
 */
export async function closePool() {
  await pool.end();
}
